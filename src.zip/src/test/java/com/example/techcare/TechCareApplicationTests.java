package com.example.techcare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechCareApplicationTests {

    @Test
    void contextLoads() {
    }

}
