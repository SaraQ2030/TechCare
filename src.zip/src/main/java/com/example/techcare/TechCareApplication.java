package com.example.techcare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechCareApplication {

    public static void main(String[] args) {
        SpringApplication.run(TechCareApplication.class, args);
    }

}
